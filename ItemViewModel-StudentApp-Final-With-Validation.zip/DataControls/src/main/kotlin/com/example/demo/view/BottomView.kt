package com.example.demo.view

import com.example.demo.controller.MainController
import javafx.beans.property.SimpleStringProperty
import tornadofx.*

class BottomView : View("My View") {
    val mainController: MainController by inject()

    val firstName = SimpleStringProperty()
    val lastName = SimpleStringProperty()

    override val root = form {
           fieldset {
               field("Add First Name") {
                    textfield(firstName)
               }
               field("Add Last Name") {
                   textfield(lastName)
               }
           }

        hbox {
             button {
                 text = "Save Student"


                 action {
                     if (firstName.value.isNullOrEmpty() || lastName.value.isNullOrEmpty()) {
                         //for now we do nothing
                     }else {
                         val fullName = firstName.value + " " + lastName.value

                         mainController.addStudent( fullName)

                         firstName.value = ""
                         lastName.value = ""
                     }


                 }
             }
        }

    }

}
