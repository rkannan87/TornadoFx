package com.example.demo.view

import com.example.demo.controller.MainController
import com.example.demo.model.Student
import com.example.demo.model.StudentModel
import javafx.beans.property.SimpleObjectProperty
import javafx.beans.property.SimpleStringProperty
import tornadofx.*
import java.time.LocalDate

class StudentEditor : View("My View") {
    val mainController: MainController by inject()
    val model: StudentModel by inject()
//    val firstName = SimpleStringProperty()
//    val lastName = SimpleStringProperty()
//    val dob = SimpleObjectProperty<LocalDate>()

    override val root = form {
         fieldset {
              field("First Name") {
                  textfield(model.firstName){
                     // required()
                      validator {
                           if (it.isNullOrBlank()) error("This is required now!!") else null
                      }
                  }

              }
             field("Last name") {
                 textfield(model.lastName).required()
             }
             field("DOB") {

                      datepicker(model.birthday).required()


             }
         }

        hbox {
            button("Save") {
                enableWhen(model.dirty)
                action {

                    model.commit {
                        var student = Student(1, model.firstName.value, model.lastName.value,
                                model.birthday.value)
                        //save to our datasource
                        mainController.addNewStudent(student)

                    }


                }

            }
            button("Reset") {
                enableWhen(model.dirty)
                action {
                      model.rollback()
                }

            }


        }


    }
}
