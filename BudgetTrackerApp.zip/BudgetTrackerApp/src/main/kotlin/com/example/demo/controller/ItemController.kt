package com.example.demo.controller

import com.example.demo.model.ExpensesEntry
import com.example.demo.model.ExpensesEntryModel
import com.example.demo.model.ExpensesEntryTbl
import com.example.demo.model.toExpensesEntry
import com.example.demo.util.execute
import com.example.demo.util.toDate
import javafx.collections.FXCollections
import javafx.collections.ObservableList
import javafx.scene.chart.PieChart
import org.jetbrains.exposed.sql.*
import tornadofx.*
import java.math.BigDecimal
import java.time.LocalDate

class ItemController : Controller() {

    //Get All items!!
    private val listOfItems: ObservableList<ExpensesEntryModel> = execute {
          ExpensesEntryTbl.selectAll().map {
              ExpensesEntryModel().apply {
                   item = it.toExpensesEntry()
              }
          }.observable()
    }
    var items: ObservableList<ExpensesEntryModel> by singleAssign()
    var pieItemsData = FXCollections.observableArrayList<PieChart.Data>()


    init {
        items = listOfItems

        items.forEach {
            pieItemsData.add(PieChart.Data(it.itemName.value, it.itemPrice.value.toDouble()))
        }



//
//
//
//          listOfItems.forEach {
//               print("Item::: ${it.itemName.value}")
//          }
    }


    fun add(newEntryDate: LocalDate, newItem: String, newPrice: Double): ExpensesEntry {
        val newEntry = execute {
            com.example.demo.model.ExpensesEntryTbl.insert {
                it[entryDate] = newEntryDate.toDate()
                it[itemName] = newItem
                it[itemPrice] = BigDecimal.valueOf(newPrice)
            }
        }

        listOfItems.add(
                 ExpensesEntryModel().apply {
                     item = ExpensesEntry(newEntry[ExpensesEntryTbl.id], newEntryDate, newItem, newPrice)

                 }
        )
        pieItemsData.add(PieChart.Data(newItem, newPrice))

        return ExpensesEntry(newEntry[ExpensesEntryTbl.id], newEntryDate, newItem, newPrice)
    }

    fun update(updatedItem: ExpensesEntryModel): Int {
        return execute {
            ExpensesEntryTbl.update({ ExpensesEntryTbl.id eq (updatedItem.id.value.toInt()) }) {
                it[entryDate] = updatedItem.entryDate.value.toDate()
                it[itemName] = updatedItem.itemName.value
                it[itemPrice] = BigDecimal.valueOf(updatedItem.itemPrice.value.toDouble())
            }
        }
    }

    fun delete(model: ExpensesEntryModel) {
        execute {
             ExpensesEntryTbl.deleteWhere {
                  ExpensesEntryTbl.id eq (model.id.value.toInt())
             }
        }
        listOfItems.remove(model)
        removeModelFromPie(model)
    }

    fun updatePiecePie(model: ExpensesEntryModel) {
       val modelId = model.id
        var currIndex: Int
        items.forEachIndexed { index, data ->
              if (modelId  == data.id) {
                  //we have the right object to update
                  currIndex = index
                  pieItemsData[currIndex].name = data.itemName.value
                  pieItemsData[currIndex].pieValue = data.itemPrice.value.toDouble()
              }else {
                   //Ignore!
              }
        }


    }








    private fun removeModelFromPie(model: ExpensesEntryModel) {
      var currIndex = 0
        pieItemsData.forEachIndexed { index, data ->
             if (data.name  == model.itemName.value && index != -1) {
                 currIndex = index
             }

        }
        pieItemsData.removeAt(currIndex)


    }

    fun filterByEntryDates(today: LocalDate?): ObservableList<ExpensesEntryModel> = execute {
         ExpensesEntryTbl
                 .select { ExpensesEntryTbl.entryDate eq today!!.toDate() }
                 .map {
                      ExpensesEntryModel().apply {
                           item = it.toExpensesEntry()
                      }
                 }.observable()
    }


}