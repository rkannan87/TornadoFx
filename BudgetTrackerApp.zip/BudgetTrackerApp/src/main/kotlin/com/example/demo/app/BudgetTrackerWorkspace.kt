package com.example.demo.app

import com.example.demo.controller.ItemController
import com.example.demo.model.ExpensesEntryTbl
import com.example.demo.util.createTables
import com.example.demo.util.enableConsoleLogger
import com.example.demo.util.execute
import com.example.demo.util.toDate
import com.example.demo.view.ExpensesEditor
import com.example.demo.view.ExpensesReport
import javafx.scene.control.TabPane
import org.jetbrains.exposed.sql.Database
import org.jetbrains.exposed.sql.insert
import tornadofx.*
import java.math.BigDecimal
import java.time.LocalDate

class BudgetTrackerWorkspace : Workspace("Budget Tracker Workspace", NavigationMode.Tabs) {

    init {
        //we initialize db etc...
        enableConsoleLogger()
        Database.connect("jdbc:sqlite:./app-budget-tracker.db", "org.sqlite.JDBC")
        createTables()





        //Controller(es)
        ItemController()

        //doc our views
        dock<ExpensesEditor>()
        dock<ExpensesReport>()


        tabContainer.tabClosingPolicy = TabPane.TabClosingPolicy.UNAVAILABLE
    }

}
