package com.example.demo.app

import javafx.scene.paint.Color
import javafx.scene.text.FontWeight
import tornadofx.*

class Styles : Stylesheet() {
    companion object {
        val heading by cssclass()
        val vBoxx by cssclass()


    }

    init {


        vBoxx {
            padding = box(10.px)
            backgroundColor = multi(c(red = 0.0,
                      green = 25.0/255, blue = 51.0/255.0))
        }

        label and heading {
            padding = box(10.px)
            fontSize = 20.px
            fontWeight = FontWeight.BOLD
            textFill = Color.WHITE

        }
    }
}