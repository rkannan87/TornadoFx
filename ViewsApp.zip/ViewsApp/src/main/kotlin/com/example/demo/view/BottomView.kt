package com.example.demo.view

import javafx.geometry.Pos
import tornadofx.*

class BottomView : View("My View") {
    override val root = label("Footer")
}
