package com.example.demo.view

import tornadofx.*

class CenterView : View("My View") {
    override val root = borderpane {
        center {   button("Center Button") }

    }
}
