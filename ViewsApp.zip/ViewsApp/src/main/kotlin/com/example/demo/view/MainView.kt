package com.example.demo.view

import com.example.demo.app.Styles
import javafx.geometry.Pos
import tornadofx.*

class MainView : View("Hello Views") {
    override fun onUndock() {
        print("Undock")
        super.onUndock()
    }

    override fun onDock() {
        print("Dock")
        super.onDock()
    }

    override fun onCreate() {
        print("On Create")
        super.onCreate()
    }

    override fun onBeforeShow() {
        print("Before Show!!")
        super.onBeforeShow()
    }

    val topView: TopView by inject()

    val centerView = find(CenterView::class)

    override val root = borderpane {
        //top, bottom, center, left, right

        //Directly embedding Views
//        top<TopView>()

        //Creating a lazy reference to top and center Views
        top = topView.root
        center = centerView.root

        bottom<BottomView>()

        left {
            label("Left")
        }

        right {
            label("Right")
        }
    }


}