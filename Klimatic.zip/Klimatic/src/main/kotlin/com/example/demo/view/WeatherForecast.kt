package com.example.demo.view

import com.example.demo.app.Styles
import com.example.demo.controller.ForecastController
import com.example.demo.model.ForecastPayload
import com.example.demo.model.Lista
import de.jensd.fx.glyphs.fontawesome.FontAwesomeIcon
import de.jensd.fx.glyphs.fontawesome.FontAwesomeIconView
import javafx.beans.binding.Bindings
import javafx.geometry.Orientation.VERTICAL
import javafx.geometry.Pos
import javafx.scene.control.Label
import javafx.scene.input.KeyCode
import javafx.scene.layout.HBox
import javafx.scene.layout.VBox
import javafx.scene.paint.Color
import javafx.scene.text.FontPosture
import tornadofx.*


class WeatherForecast : View("Klimatic") {
    val controller: ForecastController by inject()
    var forecastPayload = ForecastPayload()

    var cityLabel: Label by singleAssign()
    var todayTemp: Label by singleAssign()
    var todayIcon: Label by singleAssign()
    var forecastView: DataGrid<Lista> by singleAssign()
    var sevenDayLabel: Label by singleAssign()
    var dividerHB: HBox by singleAssign()


    init {
        controller.listPayload(cityName = "mumbai")

    }

    override val root = borderpane {
        style {
            backgroundColor += c("#666699")
        }
        center = vbox {
            addClass(Styles.contentWrapper)
            currentWeatherView()
            vbox(alignment = Pos.CENTER) {
                cityLabel = label()
                todayIcon = label()
                todayTemp = label()
                sevenDayLabel = label()
                dividerHB = hbox()
                forecastView = datagrid()


            }
        }

    }

    private fun VBox.currentWeatherView() = vbox {
        form {
            paddingAll = 20.0
            fieldset {
                field("Enter City", VERTICAL) {
                    textfield(controller.selectedCity.name) {
                        this.required()
                        validator {
                            if (it.isNullOrBlank()) error("The city field cannot be blank")
                            else null
                        }

                        setOnKeyPressed {
                            if (it.code == KeyCode.ENTER) {
                                controller.selectedCity.commit {
                                    runAsync {

                                        controller.allWeather = controller.listPayload(cityName = controller.selectedCity.name.value)

                                    } ui {
                                        forecastPayload = controller.allWeather[0]
                                        vbox {
                                            cityLabel.text = forecastPayload.city.name + "," +
                                                    " " + forecastPayload.city.country + "" +
                                                    " - " + controller.getFormattedDate(forecastPayload.lista[0].dt.toLong())
                                            cityLabel.apply {
                                                addClass(Styles.mainLabels)
                                            }

                                            todayIcon.graphic = imageview("../resources/${controller.getIcon(
                                                    forecastPayload.lista[0].weather[0].main
                                            )}.png",
                                                    lazyload = true) {
                                                fitHeight = 200.0
                                                fitWidth = 200.0
                                            }
                                            paddingBottom = 10.0

                                            todayTemp.text = "${forecastPayload.lista[0].temp.day} °F " +
                                                    " " + forecastPayload.lista[0].weather[0].description
                                            todayTemp.apply {
                                                addClass(Styles.mainLabels)
                                            }

                                            dividerHB.style {
                                                 borderColor += box(Color.TRANSPARENT, Color.TRANSPARENT,
                                                          Color.GRAY, Color.TRANSPARENT)
                                            }
                                            sevenDayLabel.text = "7-Day Weather Forecast"
                                            sevenDayLabel.style {
                                                 fill = Color.GREY
                                                fontStyle = FontPosture.ITALIC
                                                opacity = 0.7
                                            }

                                            forecastView.items = forecastPayload.lista.observable()
                                            forecastView.apply {
                                                 cellWidth = 120.0
                                                cellHeight = 200.0
                                                cellCache {
                                                      stackpane {
                                                           vbox(alignment = Pos.TOP_CENTER) {
                                                                label(controller.getFormattedDate(it.dtProperty.value
                                                                        .toLong())
                                                                        .split(",")[0])

                                                               label{
                                                                    graphic = imageview("../resources/${
                                                                    controller.getIcon(it.weather[0].mainProperty.value)
                                                                    }.png").apply {
                                                                         fitHeight = 100.0
                                                                        fitWidth = 100.0
                                                                    }
                                                                   paddingBottom = 20.0
                                                               }

                                                           }
                                                          vbox(alignment = Pos.CENTER) {
                                                               paddingTop = 80.0
                                                              label(it.temp.minProperty).apply {
                                                                   graphic = FontAwesomeIconView(FontAwesomeIcon.LONG_ARROW_DOWN)
                                                              }
                                                              label(it.temp.maxProperty) {
                                                                   graphic = FontAwesomeIconView(FontAwesomeIcon.LONG_ARROW_UP)
                                                              }
                                                              label {
                                                                   this.textProperty().bind(Bindings.concat(
                                                                            "Hum: ", it.humidityProperty, "%"
                                                                   ))
                                                              }

                                                          }
                                                      }
                                                }
                                            }
                                        }
                                    }
                                }

                            }
                        }
                    }
                }

            }
        }
    }

}