package com.example.demo.controller

import com.example.demo.model.CityModel
import com.example.demo.model.ForecastPayload
import com.example.demo.util.appid
import javafx.collections.FXCollections
import tornadofx.*
import java.text.SimpleDateFormat
import java.util.*

class  ForecastController: Controller() {
    val selectedCity: CityModel by inject()

    var allWeather = FXCollections.emptyObservableList<ForecastPayload>()!!

    val api: Rest by inject()

    init {

        api.baseURI = "https://api.openweathermap.org/data/2.5/forecast/daily/"
    }

    fun getIcon(iconString: String) = when(iconString) {
         "Rain" -> "rain"
         "Clouds" -> "clouds"
         "Snow" -> "snow"
        "Clear" -> "clear"
        "Drizzle" -> "rain"
        "Fog" -> "fog"
        else -> "clear"
    }
    fun getFormattedDate(date: Long) = SimpleDateFormat("EEE, d MMM yyyy")
            .format(Date(date * 1000))
    fun listPayload(cityName: String = selectedCity.name.value)

             = api.get("?q=$cityName&appid=$appid&units=imperial")
                 .list().toModel<ForecastPayload>()

//        forecast[0].lista.forEach {
//            print("Load Forecast:::: ${it.temp.night}")
//        }


}