package com.example.demo.util

val appid = "ADD-YOUR-APPID-HERE"