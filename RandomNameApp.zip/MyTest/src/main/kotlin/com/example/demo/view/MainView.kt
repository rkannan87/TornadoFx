package com.example.demo.view

import com.example.demo.app.Styles
import com.example.demo.controller.MainController
import javafx.beans.property.SimpleIntegerProperty
import javafx.beans.property.SimpleStringProperty
import javafx.geometry.Pos
import tornadofx.*

class MainView : View("Hello TornadoFX") {

    val mainController: MainController by inject()


    //var counter = SimpleIntegerProperty(0)


    override val root = vbox {
        alignment = Pos.CENTER
        spacing = 10.0

        label(mainController.labelText) {
           // bind(mainController.labelText)
            addClass(Styles.heading)
        }

        button{
            this.text = "Click Me!"
            action {
                mainController.getRandomName()

            }

        }


    }

}