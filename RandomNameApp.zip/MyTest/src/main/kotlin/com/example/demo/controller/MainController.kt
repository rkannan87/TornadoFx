package com.example.demo.controller

import javafx.beans.property.SimpleStringProperty
import tornadofx.*

class MainController: Controller() {

     val labelText = SimpleStringProperty()
    private val namesList = listOf(
            "Kilimanjaro",
            "Dino",
            "Lino",
            "Sengho",
            "Genkhis"
    )

     fun getRandomName() {
        val randomInteger = (1..(namesList.size - 1)).shuffled().first()

        print("Random $randomInteger")
        labelText.value = namesList[randomInteger]
    }
}