package com.example.demo.view

import com.example.demo.controller.MainController
import com.example.demo.model.Student
import javafx.beans.property.SimpleObjectProperty
import javafx.beans.property.SimpleStringProperty
import tornadofx.*
import java.time.LocalDate

class StudentEditor : View("My View") {
    val mainController: MainController by inject()
    val firstName = SimpleStringProperty()
    val lastName = SimpleStringProperty()
    val dob = SimpleObjectProperty<LocalDate>()

    override val root = form {
         fieldset {
              field("First Name") {
                  textfield(firstName) {  }

              }
             field("Last name") {
                 textfield(lastName) {

                 }
             }
             field("DOB") {

                      datepicker(dob) {  }


             }
         }
            button("Save") {
                action {
                    var student = Student(1, firstName.value, lastName.value,
                             dob.value)
                    //save to our datasource
                    mainController.addNewStudent(student)
                }

            }

    }
}
