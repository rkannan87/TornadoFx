package com.example.demo.view

import com.example.demo.controller.MainController
import tornadofx.*

class MainView : View("Hello TornadoFX") {

    val mainController: MainController by inject()
    val bottomView: BottomView by inject()
    val topView: TopView by inject()
    val centerView: CenterView by inject()
    val studentEditor: StudentEditor by inject()


    override val root = borderpane {


        top = topView.root
        left = studentEditor.root
        center = centerView.root
        bottom = bottomView.root

//        listview(mainController.students) {
//
//            cellFormat {
//                text = it
//                if (text.contains("Emma")) {
//                    textFill = c("green", 0.4)
//                     style {
//                         fontSize = 20.px
//                     }
//                }
//
//            }
//        }
//
//        button {
//            text = "Add Student"
//            action {
//                mainController.students.add("James Rato")
//            }
//        }


    }
}