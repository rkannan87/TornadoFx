package com.example.demo.view

import com.example.demo.controller.MainController
import com.example.demo.model.Student
import tornadofx.*

class CenterView : View("My View") {
    val mainController: MainController by inject()

    override val root = tableview<Student> {
         items = mainController.studentsData

        isEditable = true

        column("ID", Student::idProperty)
        column("First Name", Student::firstNameProperty)
        column("Last Name", Student::lastNameProperty)
        readonlyColumn("Student Age", Student::age)

    }
}
