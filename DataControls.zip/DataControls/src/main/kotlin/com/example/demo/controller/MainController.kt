package com.example.demo.controller

import com.example.demo.model.Student
import javafx.collections.FXCollections
import tornadofx.*
import java.time.LocalDate

class MainController: Controller() {

//    val studentNames = listOf(
//            "Gina Machava",
//            "James Bond",
//            "Helena Mt",
//            "Georgina Emma"
//    ).observable()

    val studentsData = FXCollections.observableArrayList<Student>(
              Student(1, "Jose", "Marilla",
                      LocalDate.of(2000, 11, 20)),
            Student(1, "Cesar", "Romeo",
                    LocalDate.of(1989, 11, 10)),
            Student(1, "Rebecca", "Kay",
                    LocalDate.of(2011, 8, 3)),
            Student(1, "Carlos", "Santana",
                    LocalDate.of(1956, 1, 20))
    )

    val students = FXCollections.observableArrayList<String>(
            "Gina Machava",
            "James Bond",
            "Helena Mt",
            "Georgina Emma"
    )


    fun addStudent(fullName: String) {
        students.add(fullName)
    }

    fun addNewStudent(student: Student) {
        studentsData.add(student)
    }


}