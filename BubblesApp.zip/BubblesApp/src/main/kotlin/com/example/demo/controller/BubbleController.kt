package com.example.demo.controller

import com.example.demo.view.MainView
import javafx.animation.Interpolator
import javafx.beans.property.SimpleStringProperty
import javafx.geometry.Point2D
import javafx.scene.Node
import javafx.scene.input.MouseEvent
import javafx.scene.media.AudioClip
import javafx.scene.paint.Color
import javafx.scene.shape.Circle
import javafx.util.Duration
import tornadofx.*

class BubbleController : Controller() {
    var mText = SimpleStringProperty()
    private var audioClip = AudioClip(MainView::class.java.getResource("/celestial-sound.wav")
            .toExternalForm())

    private var circle = Circle()
    private val colorList = listOf(
            "#cdeded",
            "#1A1A1A",
            "#707070",
            "#8E8E38",
            "#71C671",
            "#7171C6",
            "#800000",
            "#EE0000",
            "#CD5C5C",
            "#CDC5BF",
            "#8B7765",
            "#FF8000",
            "#E3CF57",
            "#8B8B00",
            "#6B8E23",
            "#00EE76",
            "#2F4F4F",
            "#00BFFF",
            "#1E90FF",
            "#6E7B8B",
            "#00008B",
            "#AB82FF",
            "#9400D3",
            "#FF00FF",
            "#FFBBFF",
            "#C71585"
    )

    private val listOfText = listOf("Be Brave", "Be Happy", "Carry On", "" +
            "Keep Learning", "You Can Do It!", "Hakuna Matata!", "Live and Learn", "Be Grateful",
            "Keep Going", "See the World", "Drink Water", "Eat Well", "Be Well", "Travel the World",
            "Think Different", "Assess Everything", "Live", "Do", "Sing", "Cry", "Enjoy", "Play Music",
            "Be the Change in the World", "Be a Force of Nature", "BE YOU")


    fun addCircle(it: MouseEvent, root: Node) {
        val mousePt: Point2D = root.sceneToLocal(it.sceneX, it.sceneY)

        if (audioClip.isPlaying) {
            audioClip.volumeProperty().value = 0.3
            audioClip.panProperty().value = 1.0
        } else {
            audioClip.volumeProperty().value = 0.8
            audioClip.play()
        }

        circle = Circle(mousePt.x, mousePt.y, 14.5, Color.ORANGERED)
        circle.apply {
            animateFill(Duration.seconds(1.9), c(randomColor()),
                    Color.TRANSPARENT)
        }
        timeline {
            keyframe(Duration.seconds(3.0)) {
                keyvalue(circle.radiusProperty(), 200, Interpolator.EASE_BOTH)
                //keyvalue(circle.centerYProperty(), 100, Interpolator.EASE_BOTH)
                //keyvalue(circle.centerXProperty(), 100, Interpolator.EASE_IN)
            }
        }


        root.getChildList()!!.add(circle)


    }

    fun addRandomText() {
        val listSize = listOfText.size
        val randomNum = (0 until listSize).shuffled().last()

        mText.set(listOfText[randomNum])
    }

    private fun randomColor(): String {
        val listSize = colorList.size
        val randomNum = (0 until listSize).shuffled().last()

        return colorList[randomNum]
    }

}