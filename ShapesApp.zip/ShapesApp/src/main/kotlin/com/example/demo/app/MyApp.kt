package com.example.demo.app

import com.example.demo.view.MainView
import javafx.stage.Stage
import tornadofx.*

class MyApp: App(MainView::class, Styles::class) {
    init {
        reloadStylesheetsOnFocus()
        reloadViewsOnFocus()
    }
    override fun start(stage: Stage) {
        with(stage) {
            minWidth = 800.0
            minHeight = 600.0
            // isResizable = false
            super.start(this)
        }

    }
}